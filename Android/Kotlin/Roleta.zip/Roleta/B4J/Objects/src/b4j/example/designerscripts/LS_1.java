package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_1{

public static void LS_general(anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale) {
;
//BA.debugLineNum = 3;BA.debugLine="imgvalor.SetLeftAndRight(26%x,34%x)"[1/General script]
views.get("imgvalor").setLeft((int)((26d / 100 * width)));
views.get("imgvalor").setPrefWidth((int)((34d / 100 * width) - ((26d / 100 * width))));
//BA.debugLineNum = 4;BA.debugLine="imgvalor.SetTopAndBottom(0%y,15%y)"[1/General script]
views.get("imgvalor").setTop((int)((0d / 100 * height)));
views.get("imgvalor").setPrefHeight((int)((15d / 100 * height) - ((0d / 100 * height))));
//BA.debugLineNum = 6;BA.debugLine="cvroleta.SetLeftAndRight(5%x,55%x)"[1/General script]
views.get("cvroleta").setLeft((int)((5d / 100 * width)));
views.get("cvroleta").setPrefWidth((int)((55d / 100 * width) - ((5d / 100 * width))));
//BA.debugLineNum = 7;BA.debugLine="cvroleta.SetTopAndBottom(10%y,95%y)"[1/General script]
views.get("cvroleta").setTop((int)((10d / 100 * height)));
views.get("cvroleta").setPrefHeight((int)((95d / 100 * height) - ((10d / 100 * height))));
//BA.debugLineNum = 12;BA.debugLine="btstart.SetLeftAndRight(60%x,80%x)"[1/General script]
views.get("btstart").setLeft((int)((60d / 100 * width)));
views.get("btstart").setPrefWidth((int)((80d / 100 * width) - ((60d / 100 * width))));
//BA.debugLineNum = 13;BA.debugLine="btstart.SetTopAndBottom(10%y,20%y)"[1/General script]
views.get("btstart").setTop((int)((10d / 100 * height)));
views.get("btstart").setPrefHeight((int)((20d / 100 * height) - ((10d / 100 * height))));
//BA.debugLineNum = 16;BA.debugLine="lb1premio.SetLeftAndRight(60%x,80%x)"[1/General script]
views.get("lb1premio").setLeft((int)((60d / 100 * width)));
views.get("lb1premio").setPrefWidth((int)((80d / 100 * width) - ((60d / 100 * width))));
//BA.debugLineNum = 17;BA.debugLine="lb1premio.SetTopAndBottom(25%y,35%y)"[1/General script]
views.get("lb1premio").setTop((int)((25d / 100 * height)));
views.get("lb1premio").setPrefHeight((int)((35d / 100 * height) - ((25d / 100 * height))));
//BA.debugLineNum = 20;BA.debugLine="lbpremio.SetLeftAndRight(60%x,80%x)"[1/General script]
views.get("lbpremio").setLeft((int)((60d / 100 * width)));
views.get("lbpremio").setPrefWidth((int)((80d / 100 * width) - ((60d / 100 * width))));
//BA.debugLineNum = 21;BA.debugLine="lbpremio.SetTopAndBottom(35%y,55%y)"[1/General script]
views.get("lbpremio").setTop((int)((35d / 100 * height)));
views.get("lbpremio").setPrefHeight((int)((55d / 100 * height) - ((35d / 100 * height))));

}
}