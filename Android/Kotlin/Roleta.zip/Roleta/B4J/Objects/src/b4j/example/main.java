package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.debug.*;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            BA.Log("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 1000, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _vv3 = null;
public static anywheresoftware.b4j.objects.Form _v5 = null;
public static anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _v6 = null;
public static anywheresoftware.b4a.objects.Timer _v7 = null;
public static int _v0 = 0;
public static anywheresoftware.b4a.objects.Timer _vv2 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btstart = null;
public static anywheresoftware.b4j.objects.CanvasWrapper _cvroleta = null;
public static anywheresoftware.b4j.objects.ImageViewWrapper _imgvalor = null;
public static anywheresoftware.b4a.objects.collections.List _vv1 = null;
public static int _vv4 = 0;
public static anywheresoftware.b4j.objects.LabelWrapper _lbpremio = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lb1premio = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 23;BA.debugLine="MainForm = Form1";
_v5 = _form1;
 //BA.debugLineNum = 24;BA.debugLine="MainForm.SetFormStyle(\"UNIFIED\")";
_v5.SetFormStyle("UNIFIED");
 //BA.debugLineNum = 25;BA.debugLine="MainForm.RootPane.LoadLayout(\"1\")";
_v5.getRootPane().LoadLayout(ba,"1");
 //BA.debugLineNum = 26;BA.debugLine="MainForm.Show";
_v5.Show();
 //BA.debugLineNum = 28;BA.debugLine="b.Initialize(File.DirAssets, \"valores.png\")";
_v6.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"valores.png");
 //BA.debugLineNum = 30;BA.debugLine="cvroleta.DrawImage(b,0,0,b.Width,b.height)";
_cvroleta.DrawImage((javafx.scene.image.Image)(_v6.getObject()),0,0,_v6.getWidth(),_v6.getHeight());
 //BA.debugLineNum = 31;BA.debugLine="t.Initialize(\"t\",1)";
_v7.Initialize(ba,"t",(long) (1));
 //BA.debugLineNum = 32;BA.debugLine="angulo = 0";
_v0 = (int) (0);
 //BA.debugLineNum = 34;BA.debugLine="lvalores.Initialize";
_vv1.Initialize();
 //BA.debugLineNum = 35;BA.debugLine="lvalores.AddAll(Array As String(500,100,75,35,0))";
_vv1.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{BA.NumberToString(500),BA.NumberToString(100),BA.NumberToString(75),BA.NumberToString(35),BA.NumberToString(0)}));
 //BA.debugLineNum = 39;BA.debugLine="tfinaliza.Initialize(\"tfinaliza\",1000)";
_vv2.Initialize(ba,"tfinaliza",(long) (1000));
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _btstart_action() throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Sub btstart_Action";
 //BA.debugLineNum = 86;BA.debugLine="If t.Enabled Then";
if (_v7.getEnabled()) { 
 //BA.debugLineNum = 87;BA.debugLine="tfinaliza.Enabled = True";
_vv2.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 88;BA.debugLine="btstart.Enabled = False";
_btstart.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 89;BA.debugLine="btstart.Visible = False";
_btstart.setVisible(anywheresoftware.b4a.keywords.Common.False);
 }else {
 //BA.debugLineNum = 91;BA.debugLine="btstart.Text = \"PARAR\"";
_btstart.setText("PARAR");
 //BA.debugLineNum = 93;BA.debugLine="lb1premio.Visible = False";
_lb1premio.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 94;BA.debugLine="lbpremio.Visible = False";
_lbpremio.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 95;BA.debugLine="imgvalor.Visible = True";
_imgvalor.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 96;BA.debugLine="t.Enabled=True";
_v7.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 };
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_vv3 = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_v5 = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private b As Image";
_v6 = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private t As Timer";
_v7 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 11;BA.debugLine="Private angulo As Int";
_v0 = 0;
 //BA.debugLineNum = 12;BA.debugLine="Private tfinaliza As Timer";
_vv2 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 13;BA.debugLine="Private btstart As Button";
_btstart = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private cvroleta As Canvas";
_cvroleta = new anywheresoftware.b4j.objects.CanvasWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private imgvalor As ImageView";
_imgvalor = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lvalores As List";
_vv1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 17;BA.debugLine="Private atual As Int";
_vv4 = 0;
 //BA.debugLineNum = 18;BA.debugLine="Private lbpremio As Label";
_lbpremio = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private lb1premio As Label";
_lb1premio = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public static String  _t_tick() throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub t_tick";
 //BA.debugLineNum = 44;BA.debugLine="angulo = angulo + 1";
_v0 = (int) (_v0+1);
 //BA.debugLineNum = 45;BA.debugLine="If angulo = 360 Then";
if (_v0==360) { 
 //BA.debugLineNum = 46;BA.debugLine="angulo=0";
_v0 = (int) (0);
 };
 //BA.debugLineNum = 51;BA.debugLine="cvroleta.DrawImageRotated(b,0,0,b.Width,b.Height,";
_cvroleta.DrawImageRotated((javafx.scene.image.Image)(_v6.getObject()),0,0,_v6.getWidth(),_v6.getHeight(),_v0);
 //BA.debugLineNum = 53;BA.debugLine="If angulo >= 345 And angulo <= 360 Then 'ITEM 0";
if (_v0>=345 && _v0<=360) { 
 //BA.debugLineNum = 54;BA.debugLine="atual = lvalores.Get(0)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (0))));
 }else if(_v0>=0 && _v0<=15) { 
 //BA.debugLineNum = 56;BA.debugLine="atual = lvalores.Get(0)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (0))));
 }else if(_v0>=15 && _v0<=45) { 
 //BA.debugLineNum = 58;BA.debugLine="atual = lvalores.Get(3)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (3))));
 }else if(_v0>=45 && _v0<=75) { 
 //BA.debugLineNum = 60;BA.debugLine="atual = lvalores.Get(2)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (2))));
 }else if(_v0>=75 && _v0<=105) { 
 //BA.debugLineNum = 62;BA.debugLine="atual = lvalores.Get(4)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (4))));
 }else if(_v0>=105 && _v0<=135) { 
 //BA.debugLineNum = 64;BA.debugLine="atual = lvalores.Get(1)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (1))));
 }else if(_v0>=135 && _v0<=165) { 
 //BA.debugLineNum = 66;BA.debugLine="atual = lvalores.Get(3)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (3))));
 }else if(_v0>=165 && _v0<=195) { 
 //BA.debugLineNum = 68;BA.debugLine="atual = lvalores.Get(2)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (2))));
 }else if(_v0>=195 && _v0<=225) { 
 //BA.debugLineNum = 70;BA.debugLine="atual = lvalores.Get(3)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (3))));
 }else if(_v0>=225 && _v0<=255) { 
 //BA.debugLineNum = 72;BA.debugLine="atual = lvalores.Get(1)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (1))));
 }else if(_v0>=255 && _v0<=285) { 
 //BA.debugLineNum = 74;BA.debugLine="atual = lvalores.Get(4)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (4))));
 }else if(_v0>=285 && _v0<=315) { 
 //BA.debugLineNum = 76;BA.debugLine="atual = lvalores.Get(2)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (2))));
 }else if(_v0>=315 && _v0<=345) { 
 //BA.debugLineNum = 78;BA.debugLine="atual = lvalores.Get(3)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (3))));
 }else {
 //BA.debugLineNum = 80;BA.debugLine="atual = lvalores.Get(4)";
_vv4 = (int)(BA.ObjectToNumber(_vv1.Get((int) (4))));
 };
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public static String  _tfinaliza_tick() throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Sub tfinaliza_Tick";
 //BA.debugLineNum = 102;BA.debugLine="If t.Interval < 10 Then";
if (_v7.getInterval()<10) { 
 //BA.debugLineNum = 103;BA.debugLine="t.Interval = t.Interval + 1";
_v7.setInterval((long) (_v7.getInterval()+1));
 }else {
 //BA.debugLineNum = 105;BA.debugLine="tfinaliza.Enabled = False";
_vv2.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 106;BA.debugLine="t.Enabled=False";
_v7.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 107;BA.debugLine="t.Interval = 1";
_v7.setInterval((long) (1));
 //BA.debugLineNum = 108;BA.debugLine="If atual < 1 Then lb1premio.Text = \"Você não gan";
if (_vv4<1) { 
_lb1premio.setText("Você não ganhou nada!");}
else {
_lb1premio.setText("Parabéns, você ganhou!");};
 //BA.debugLineNum = 109;BA.debugLine="btstart.Text = \"INICIAR\"";
_btstart.setText("INICIAR");
 //BA.debugLineNum = 110;BA.debugLine="lb1premio.Visible = True";
_lb1premio.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 111;BA.debugLine="lbpremio.Visible = True";
_lbpremio.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 112;BA.debugLine="lbpremio.Text = atual";
_lbpremio.setText(BA.NumberToString(_vv4));
 //BA.debugLineNum = 113;BA.debugLine="btstart.Enabled = True";
_btstart.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 114;BA.debugLine="btstart.Visible = True";
_btstart.setVisible(anywheresoftware.b4a.keywords.Common.True);
 };
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
}
